document.addEventListener("DOMContentLoaded", () => {
  const corpoTabela = document.getElementById("corpo-tabela");
  const totalFinal = document.getElementById("total-final");

  function carregarCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    corpoTabela.innerHTML = "";
    let total = 0;

    carrinho.forEach((item, index) => {
      const subtotal = item.preco * item.quantidade;
      total += subtotal;

      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${item.nome}</td>
        <td>R$ ${item.preco.toFixed(2)}</td>
        <td>${item.quantidade}</td>
        <td>R$ ${subtotal.toFixed(2)}</td>
        <td><button onclick="removerItem(${index})">Remover</button></td>
      `;
      corpoTabela.appendChild(tr);
    });

    totalFinal.textContent = "Total: R$ " + total.toFixed(2);
  }

  window.removerItem = function(index) {
    const carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
    carrinho.splice(index, 1);
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    carregarCarrinho();
  };

  carregarCarrinho();
});

function adicionarCarrinho(nome, preco) {
  const carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
  const index = carrinho.findIndex(p => p.nome === nome);
  if (index >= 0) {
    carrinho[index].quantidade += 1;
  } else {
    carrinho.push({ nome, preco, quantidade: 1 });
  }
  localStorage.setItem("carrinho", JSON.stringify(carrinho));
  alert(nome + " adicionado ao carrinho!");
}
