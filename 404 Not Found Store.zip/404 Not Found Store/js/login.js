function fazerLogin() {
  const usuario = document.getElementById('username').value;
  const senha = document.getElementById('password').value;
  const mensagem = document.getElementById('mensagem');

  if (usuario === "admin" && senha === "1234") {
    window.location.href = "adm.html";
  } else if (usuario ==="usuario" &&  senha === "1234") {
    window.location.href = "home.html";
  } else {
    mensagem.textContent = "Preencha todos os campos!";
  }
}
