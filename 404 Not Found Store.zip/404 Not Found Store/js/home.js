function adicionarCarrinho(nome, preco) {
  alert(`"${nome}" foi adicionado ao carrinho!\nPreço: R$ ${preco.toFixed(2)}`);
  // Aqui você pode armazenar no localStorage ou enviar para o backend futuramente
}
